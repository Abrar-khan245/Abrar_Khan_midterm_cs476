object Midterm {
  def main(args: Array[String]): Unit = {
    val m = Map("q"->"1","u"->"2","i"->"3","t"->"4")
    scala.collection.immutable.Map[java.lang.String,Int] = Map(q -> 1, u -> 2,i -> 3,t -> 4)
      Scope{


      }

  }


}
